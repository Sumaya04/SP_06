// Initialize cart from localStorage or create an empty array if none exists
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Add item to cart
function addToCart(name, price) {
    cart.push({ name, price });
    localStorage.setItem('cart', JSON.stringify(cart)); // Store updated cart in localStorage
    alert(`${name} has been added to your cart!`);
}

// Display cart items on the cart page
function updateCartDisplay() {
    const cartItemsSection = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    cartItemsSection.innerHTML = ""; // Clear previous items

    if (cart.length === 0) {
        cartItemsSection.innerHTML = "<p>Your cart is empty.</p>";
        cartTotal.innerHTML = ""; // Clear the total if cart is empty
        return;
    }

    // Display each item in the cart
    let total = 0;
    cart.forEach((item, index) => {
        const itemElement = document.createElement('div');
        itemElement.className = 'cart-item';
        itemElement.innerHTML = `
            <span>${item.name} - $${item.price}</span>
            <button onclick="removeFromCart(${index})">Remove</button>
        `;
        cartItemsSection.appendChild(itemElement);
        total += item.price;
    });

    // Display the total price
    cartTotal.innerHTML = `<h3>Total: $${total.toFixed(2)}</h3>`;
}

// Remove item from cart by index and update localStorage
function removeFromCart(index) {
    cart.splice(index, 1); // Remove item at specified index
    localStorage.setItem('cart', JSON.stringify(cart)); // Update cart in localStorage
    updateCartDisplay(); // Refresh the display
}

// Function to initiate checkout process
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
    } else {
        window.location.href = "login.html"; // Redirect to login if cart has items
    }
}

// Function for login process (simulated)
function login(event) {
    event.preventDefault();
    alert("Logged in successfully!");
    window.location.href = "cart.html"; // Redirect to cart page after login
}

// Register user function
function register(event) {
    event.preventDefault();
    alert("Registration successful! You can now log in.");
    window.location.href = "login.html"; // Redirect to login page after registration
}

// Update cart display if on the cart page
if (document.getElementById('cart-items')) {
    updateCartDisplay();
}

document.getElementById('profileForm').addEventListener('submit', function (event) {
    const email = document.getElementById('email').value;

    if (!email.includes('@')) {
        alert('Please enter a valid email address.');
        event.preventDefault();
    }
});

