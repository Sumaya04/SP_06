<?php
session_start(); 

// Database connection
$servername = "localhost";
$username = "root";  
$password = "";
$dbname = "indoor_plants";

// Connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verify that session variables exist
if (!isset($_SESSION['username']) || !isset($_SESSION['email'])) {
    header("Location: login.html"); // Redirect to login if session variables are not set
    exit();
}

// Retrieve session data
$username = $_SESSION['username'];
$email = $_SESSION['email'];

// Get message from POST data
$message = isset($_POST['message']) ? $_POST['message'] : null;

// Check if message is set
if ($message === null || trim($message) === '') {
    echo "Error: Message cannot be empty.";
    exit();
}

// Prepare and bind SQL statement to insert data into the `messages` table
$stmt = $conn->prepare("INSERT INTO messages (username, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $uname, $email, $password);

// Execute the statement
if ($stmt->execute()) {
    // Redirect to a confirmation page if successful
    header("Location: messageSent.html");
    exit(); 
} else {
    echo "Error: " . $stmt->error;
}

// Close the statement and the database connection
$stmt->close();
$conn->close();
?>
